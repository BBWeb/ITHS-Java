package solutions2;

public class IfExercise1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int score = 50;
		if (score >= 50) {
			System.out.println("Godk�nt!");
		} else {
			System.out.println("Underk�nt.");
		}
		
	}

}
