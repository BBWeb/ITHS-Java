package solutions2;

public class WhileExercise2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i = 10;
		while (i >= 1) {
			System.out.println(i);
			i = i - 1;
		}
		
	}

}
