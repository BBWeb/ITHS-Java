
public class Exercise2 {

	public static void main(String[] args) {

		int a = 5;
		int b = 4;
		
		boolean variable = 5<4;
		System.out.println(!variable); // prints false

	}

}
